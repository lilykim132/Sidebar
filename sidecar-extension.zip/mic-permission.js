document.getElementById("go").addEventListener("click", async () => {
  const msg = document.getElementById("msg");
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((t) => t.stop());
    msg.className = "small ok";
    msg.textContent = "Done. Close this tab and use the Voice note button in the sidebar.";
  } catch (e) {
    msg.className = "small error";
    msg.textContent = "Access was blocked. Click the icon at the left of the address bar to allow the microphone, then try again.";
  }
});
