// Bridge: runs in every frame but only wakes up inside the Sidecar web app
// (the page marks itself with <meta name="csb-app">). It hands saved captures to the
// page and deletes each one from the sidebar's storage once the page confirms it's saved.
(function () {
  if (!document.querySelector('meta[name="csb-app"]')) return;

  let ready = false;
  let inFlight = new Set();

  async function pending() {
    const all = await chrome.storage.local.get(null);
    return Object.keys(all)
      .filter((k) => k.startsWith("cap_"))
      .map((k) => all[k])
      .filter((c) => c && !inFlight.has(c.id))
      .sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)));
  }

  async function push() {
    if (!ready) return;
    const list = (await pending()).slice(0, 5);
    if (!list.length) return;
    list.forEach((c) => inFlight.add(c.id));
    window.postMessage({ csb: "ext", type: "captures", captures: list }, "*");
    // If the page never confirms (e.g. it was closed), let these be resent later.
    setTimeout(() => { list.forEach((c) => inFlight.delete(c.id)); }, 60000);
  }

  window.addEventListener("message", async (e) => {
    if (e.source !== window || !e.data || e.data.csb !== "app") return;
    if (e.data.type === "ready") {
      ready = true;
      await chrome.storage.local.set({ lastSyncSeen: Date.now() });
      push();
    }
    if (e.data.type === "projects" && Array.isArray(e.data.names)) {
      const names = e.data.names.map(String).filter(Boolean).slice(0, 100);
      const { projects = [] } = await chrome.storage.local.get("projects");
      const merged = [...names, ...projects.filter((n) => !names.some((m) => m.toLowerCase() === String(n).toLowerCase()))];
      await chrome.storage.local.set({ projects: merged });
    }
    if (e.data.type === "ack" && Array.isArray(e.data.ids)) {
      await chrome.storage.local.remove(e.data.ids.map((id) => "cap_" + id));
      e.data.ids.forEach((id) => inFlight.delete(id));
      push();
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && Object.keys(changes).some((k) => k.startsWith("cap_") && changes[k].newValue)) push();
  });

  window.postMessage({ csb: "ext", type: "hello" }, "*");
})();
