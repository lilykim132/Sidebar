// Sidecar — Capture sidebar
// Each capture is stored under its own key (cap_<id>) until the Sidecar
// web app confirms it has saved it; bridge.js then deletes it here.

const $ = (id) => document.getElementById(id);
const APP_URL = "https://claude.ai/artifact/3jtC3qMBfeUrrMYuzJVwHN";
const state = {
  projects: [],
  settings: { mode: "panel", lastProject: "", phase: "" },
  shot: null, // { dataUrl, url, title }
};

// ---------- storage ----------
async function load() {
  const data = await chrome.storage.local.get(["projects", "captures", "settings"]);
  state.projects = data.projects && data.projects.length ? data.projects : ["Project 3"];
  if (Array.isArray(data.captures) && data.captures.length) {
    const moved = {};
    for (const c of data.captures) moved["cap_" + c.id] = c;
    await chrome.storage.local.set(moved);
  }
  await chrome.storage.local.remove("captures");
  state.settings = Object.assign({ mode: "panel", lastProject: "", phase: "" }, data.settings || {});
}
const saveProjects = () => chrome.storage.local.set({ projects: state.projects });
const saveSettings = () => chrome.storage.local.set({ settings: state.settings });

// ---------- projects ----------
function renderProjects() {
  const sel = $("project");
  sel.innerHTML = "";
  for (const p of state.projects) {
    const o = document.createElement("option");
    o.value = p; o.textContent = p;
    sel.appendChild(o);
  }
  const add = document.createElement("option");
  add.value = "__new__"; add.textContent = "+ New project…";
  sel.appendChild(add);
  sel.value = state.projects.includes(state.settings.lastProject) ? state.settings.lastProject : state.projects[0];
}
$("project").addEventListener("change", (e) => {
  if (e.target.value === "__new__") {
    $("newProjectRow").classList.remove("hidden");
    $("newProjectName").focus();
  } else {
    $("newProjectRow").classList.add("hidden");
    state.settings.lastProject = e.target.value;
    saveSettings();
  }
});
function addProject() {
  const name = $("newProjectName").value.trim();
  if (!name) return;
  if (!state.projects.includes(name)) state.projects.push(name);
  state.settings.lastProject = name;
  saveProjects(); saveSettings();
  $("newProjectName").value = "";
  $("newProjectRow").classList.add("hidden");
  renderProjects();
}
$("newProjectSave").addEventListener("click", addProject);
$("newProjectName").addEventListener("keydown", (e) => { if (e.key === "Enter") addProject(); });

// ---------- phase ----------
function renderPhase() {
  document.querySelectorAll("#phases .ph").forEach((b) => {
    b.setAttribute("aria-checked", String(b.dataset.phase === state.settings.phase));
  });
}
document.querySelectorAll("#phases .ph").forEach((b) => {
  b.addEventListener("click", () => {
    state.settings.phase = b.dataset.phase;
    saveSettings();
    renderPhase();
  });
});

// ---------- screenshot ----------
function downscale(dataUrl, maxW = 1600) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxW / img.width);
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * scale);
      c.height = Math.round(img.height * scale);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      resolve(c.toDataURL("image/jpeg", 0.82));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

async function takeScreenshot() {
  $("shotError").classList.add("hidden");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const raw = await chrome.tabs.captureVisibleTab(undefined, { format: "jpeg", quality: 85 });
    const dataUrl = await downscale(raw);
    state.shot = { dataUrl, url: tab ? tab.url : "", title: tab ? tab.title : "" };
    renderShot();
  } catch (err) {
    $("shotError").textContent = "Couldn't screenshot this page (Chrome blocks pages like chrome:// and the Web Store). You can still save a note.";
    $("shotError").classList.remove("hidden");
  }
}
function renderShot() {
  if (state.shot) {
    $("shotImg").src = state.shot.dataUrl;
    let host = "";
    try { host = new URL(state.shot.url).hostname; } catch (_) {}
    $("shotSource").textContent = [host, state.shot.title].filter(Boolean).join(" · ");
    $("shotSource").title = state.shot.title || "";
    $("shotEmpty").classList.add("hidden");
    $("shotFilled").classList.remove("hidden");
  } else {
    $("shotEmpty").classList.remove("hidden");
    $("shotFilled").classList.add("hidden");
  }
}
$("takeShot").addEventListener("click", takeScreenshot);
$("retake").addEventListener("click", takeScreenshot);
$("removeShot").addEventListener("click", () => { state.shot = null; renderShot(); });

// ---------- voice ----------
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let rec = null;
let listening = false;
function setMic(on) {
  listening = on;
  $("mic").setAttribute("aria-pressed", String(on));
  $("micLabel").textContent = on ? "Listening… tap to stop" : "Voice note";
}
$("mic").addEventListener("click", () => {
  $("micError").classList.add("hidden");
  if (!SR) {
    $("micError").textContent = "Voice isn't supported in this browser. Type instead.";
    $("micError").classList.remove("hidden");
    return;
  }
  if (listening && rec) { rec.stop(); return; }
  rec = new SR();
  rec.lang = navigator.language || "en-US";
  rec.continuous = true;
  rec.interimResults = false;
  const base = $("note").value;
  let added = "";
  rec.onresult = (e) => {
    for (let i = e.resultIndex; i < e.results.length; i++) {
      if (e.results[i].isFinal) added += (added ? " " : "") + e.results[i][0].transcript.trim();
    }
    $("note").value = (base ? base.trimEnd() + " " : "") + added;
  };
  rec.onerror = (e) => {
    setMic(false);
    if (e.error === "not-allowed" || e.error === "service-not-allowed") {
      $("micError").innerHTML = "";
      const t = document.createTextNode("Chrome needs microphone permission first. ");
      const b = document.createElement("button");
      b.className = "link"; b.textContent = "Grant access";
      b.addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("mic-permission.html") }));
      $("micError").append(t, b);
      $("micError").classList.remove("hidden");
    }
  };
  rec.onend = () => setMic(false);
  try { rec.start(); setMic(true); } catch (_) { setMic(false); }
});

// ---------- save ----------
function uid() {
  return "cap" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
function toast(msg) {
  $("toast").textContent = msg;
  $("toast").classList.remove("hidden");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => $("toast").classList.add("hidden"), 2500);
}
async function saveCapture() {
  const note = $("note").value.trim();
  if (!note && !state.shot) { toast("Add a note or a screenshot first."); return; }
  if (listening && rec) rec.stop();
  let url = state.shot ? state.shot.url : "";
  let title = state.shot ? state.shot.title : "";
  if (!state.shot) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) { url = tab.url || ""; title = tab.title || ""; }
    } catch (_) {}
  }
  const project = $("project").value === "__new__" ? (state.projects[0] || "Project 3") : $("project").value;
  const capture = {
    id: uid(),
    project,
    note,
    imageDataUrl: state.shot ? state.shot.dataUrl : null,
    url, title,
    starred: $("star").checked,
    phase: state.settings.phase || null,
    createdAt: new Date().toISOString(),
  };
  try {
    await chrome.storage.local.set({ ["cap_" + capture.id]: capture });
  } catch (err) {
    toast("Couldn't save — storage is full. Open Sidecar so waiting captures can sync.");
    return;
  }
  $("note").value = "";
  $("star").checked = false;
  state.shot = null;
  renderShot();
  toast("Saved to " + project + " → Sidecar");
}
$("save").addEventListener("click", saveCapture);
$("note").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); saveCapture(); }
});

// ---------- sync status ----------
async function renderSync() {
  const all = await chrome.storage.local.get(null);
  const waiting = Object.keys(all).filter((k) => k.startsWith("cap_")).length;
  const el = $("sync");
  el.innerHTML = "";
  el.classList.toggle("waiting", waiting > 0);
  const dot = document.createElement("span");
  dot.className = "dot";
  const txt = document.createElement("span");
  txt.className = "grow";
  if (waiting === 0) {
    txt.textContent = "All captures are in Sidecar";
    el.append(dot, txt);
  } else {
    txt.textContent = waiting + " waiting to sync. Open Sidecar in a tab and they'll go in automatically.";
    const open = document.createElement("button");
    open.className = "link";
    open.textContent = "Open";
    open.addEventListener("click", () => chrome.tabs.create({ url: APP_URL }));
    el.append(dot, txt, open);
  }
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (Object.keys(changes).some((k) => k.startsWith("cap_"))) renderSync();
  if (changes.projects && Array.isArray(changes.projects.newValue) && $("project").value !== "__new__") {
    state.projects = changes.projects.newValue.length ? changes.projects.newValue : state.projects;
    renderProjects();
  }
});

// ---------- mode ----------
function renderMode() {
  $("modePanel").classList.toggle("on", state.settings.mode === "panel");
  $("modeInstant").classList.toggle("on", state.settings.mode === "instant");
}
$("modePanel").addEventListener("click", () => { state.settings.mode = "panel"; saveSettings(); renderMode(); });
$("modeInstant").addEventListener("click", () => { state.settings.mode = "instant"; saveSettings(); renderMode(); });

// ---------- start ----------
(async function init() {
  await load();
  renderProjects();
  renderMode();
  renderPhase();
  renderShot();
  renderSync();
  if (state.settings.mode === "instant") takeScreenshot();
  $("note").focus();
})();
